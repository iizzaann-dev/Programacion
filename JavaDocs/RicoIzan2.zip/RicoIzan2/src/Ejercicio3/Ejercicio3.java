/*
 * Descripción: Se pide que se declaren e inicien varias variables y que se imprima en pantalla cierta información
 * Autor: Izan Rico Blanco
 * Fecha: 06/10/25
 */

package Ejercicio3;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		int num1 = 1;
		int num2 = 1;
		char char1 = 'z';
		char char2 = 'y';
		String Cargo = "Teniente";
		String Nombre = "Salazar";
		
		System.out.println("Buenas, el valor de las variables tipo int son las siguientes, num1: " + num1 + ", y num2: " + num2 + ".");
		System.out.println("Bienveido " + Cargo + " " + Nombre + ".");
		

	}

}
