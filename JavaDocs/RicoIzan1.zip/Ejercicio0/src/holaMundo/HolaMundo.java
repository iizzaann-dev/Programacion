package holaMundo;

public class HolaMundo {

	public static void main(String[] args) {
		System.out.print("Hola mundo!!!");

	}

}

